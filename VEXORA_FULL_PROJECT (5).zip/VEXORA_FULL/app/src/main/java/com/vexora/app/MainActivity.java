package com.vexora.app;
import android.content.*; import android.graphics.Color; import android.os.Bundle; import android.view.*; import android.widget.*; import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
 int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
 TextView tv(String s,float z,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
 LinearLayout card(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(dp(14),dp(12),dp(14),dp(12));x.setBackgroundResource(com.vexora.app.R.drawable.bg_card);return x;}
 Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.BLACK);b.setBackgroundResource(R.drawable.bg_button);return b;}
 void addMenu(LinearLayout row,String icon,String name,String desc,Class<?> cls){
   LinearLayout c=card(); c.addView(tv(icon+"  "+name,16,Color.WHITE),new LinearLayout.LayoutParams(-1,dp(32)));
   c.addView(tv(desc,11,Color.GRAY),new LinearLayout.LayoutParams(-1,dp(28)));
   Button b=btn("OPEN");c.addView(b,new LinearLayout.LayoutParams(-1,dp(44)));b.setOnClickListener(v->startActivity(new Intent(this,cls)));
   LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(142),1); if(row.getChildCount()>0)p.setMargins(dp(8),0,0,0);row.addView(c,p);
 }
 protected void onCreate(Bundle b){super.onCreate(b);
   LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(dp(16),dp(12),dp(16),dp(10));r.setBackgroundColor(Color.rgb(5,7,6));
   TextView logo=tv("VEXORA",28,Color.rgb(120,240,0));logo.setGravity(Gravity.CENTER);logo.setTypeface(null,1);r.addView(logo,new LinearLayout.LayoutParams(-1,dp(44)));
   TextView sub=tv("GAMING PERFORMANCE",11,Color.GRAY);sub.setGravity(Gravity.CENTER);r.addView(sub,new LinearLayout.LayoutParams(-1,dp(22)));
   LinearLayout st=card();st.addView(tv("DEVICE STATUS",11,Color.GRAY));st.addView(tv("●  OPTIMAL",18,Color.rgb(120,240,0)));r.addView(st,new LinearLayout.LayoutParams(-1,dp(76)));
   TextView q=tv("QUICK MENU",13,Color.WHITE);q.setTypeface(null,1);q.setPadding(0,dp(12),0,dp(7));r.addView(q,new LinearLayout.LayoutParams(-1,dp(38)));
   LinearLayout row1=new LinearLayout(this);row1.setOrientation(LinearLayout.HORIZONTAL);
   addMenu(row1,"🎮","FREE FIRE","Launch game",MainActivity.class);
   addMenu(row1,"🐸","FROG","Device optimizer",FrogActivity.class);r.addView(row1,new LinearLayout.LayoutParams(-1,dp(142)));
   LinearLayout row2=new LinearLayout(this);row2.setOrientation(LinearLayout.HORIZONTAL);row2.setPadding(0,dp(8),0,0);
   addMenu(row2,"⚡","BOOST","Performance mode",FrogActivity.class);addMenu(row2,"🎯","MACRO","UI & presets",MacroActivity.class);r.addView(row2,new LinearLayout.LayoutParams(-1,dp(150)));
   LinearLayout row3=new LinearLayout(this);row3.setOrientation(LinearLayout.HORIZONTAL);row3.setPadding(0,dp(8),0,0);
   addMenu(row3,"🛠","TOOLS","Utilities",ToolsActivity.class);addMenu(row3,"⚙","SETTINGS","App settings",SettingsActivity.class);r.addView(row3,new LinearLayout.LayoutParams(-1,dp(150)));
   Button lib=btn("🎮  GAME LIBRARY  +  ADD GAME");lib.setTextColor(Color.BLACK);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52));lp.setMargins(0,dp(8),0,0);r.addView(lib,lp);lib.setOnClickListener(v->startActivity(new Intent(this,GameLibraryActivity.class)));
   TextView note=tv("VEXORA optimizes device-side settings only. It does not automate game input.",10,Color.GRAY);note.setGravity(Gravity.CENTER);r.addView(note,new LinearLayout.LayoutParams(-1,0,1));
   setContentView(r);
 }
}