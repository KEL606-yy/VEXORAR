package com.vexora.app;
import android.content.*;import android.graphics.Color;import android.os.*;import android.provider.Settings;import android.view.*;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;
public class FrogActivity extends AppCompatActivity{
 int dp(float x){return(int)(x*getResources().getDisplayMetrics().density+.5f);} TextView t(String s,float z,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);return v;}
 LinearLayout card(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(dp(14),dp(12),dp(14),dp(12));x.setBackgroundResource(R.drawable.bg_card);return x;}
 Switch sw(String a,String d){Switch s=new Switch(this);s.setText(a+"\n"+d);s.setTextColor(Color.WHITE);s.setTextSize(14);return s;}
 protected void onCreate(Bundle b){super.onCreate(b);LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(dp(16),dp(12),dp(16),dp(10));r.setBackgroundColor(Color.rgb(5,7,6));
 TextView h=t("‹   🐸 FROG",23,Color.rgb(120,240,0));h.setTypeface(null,1);h.setOnClickListener(v->finish());r.addView(h,new LinearLayout.LayoutParams(-1,dp(52)));
 TextView hero=t("FROG PERFORMANCE\nOPTIMIZER",24,Color.WHITE);hero.setGravity(Gravity.CENTER);r.addView(hero,new LinearLayout.LayoutParams(-1,dp(95)));
 Button verify=new Button(this);verify.setText("📷  VERIFIKASI WAJAH");verify.setTextColor(Color.BLACK);verify.setBackgroundResource(R.drawable.bg_button);r.addView(verify,new LinearLayout.LayoutParams(-1,dp(52)));
 verify.setOnClickListener(v->startActivityForResult(new Intent(this,CameraActivity.class),9));
 LinearLayout c=card();c.addView(t("OPTIMIZATION",14,Color.WHITE));Switch a=sw("Keep Screen Awake","Layar tetap menyala");Switch b2=sw("Performance Monitor","Pantau memori dan status perangkat");Switch c2=sw("Gaming Notifications","Kontrol notifikasi aplikasi");c.addView(a);c.addView(b2);c.addView(c2);r.addView(c,new LinearLayout.LayoutParams(-1,dp(220)));
 a.setOnCheckedChangeListener((x,y)->getWindow().getDecorView().setKeepScreenOn(y));
 b2.setOnCheckedChangeListener((x,y)->Toast.makeText(this,y?"Monitoring ON":"Monitoring OFF",Toast.LENGTH_SHORT).show());
 Button on=new Button(this);on.setText("AKTIFKAN FROG");on.setTextColor(Color.BLACK);on.setBackgroundResource(R.drawable.bg_button);r.addView(on,new LinearLayout.LayoutParams(-1,dp(54)));on.setOnClickListener(v->Toast.makeText(this,"FROG aktif: optimasi aman perangkat.",Toast.LENGTH_SHORT).show());
 TextView info=t("Verifikasi foto di sini adalah gate untuk fitur FROG. Versi ini belum melakukan face recognition.",10,Color.GRAY);info.setGravity(Gravity.CENTER);r.addView(info,new LinearLayout.LayoutParams(-1,0,1));setContentView(r);}
}