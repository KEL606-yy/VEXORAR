package com.vexora.app;
import android.graphics.Color;import android.os.Bundle;import android.view.*;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;
public class SettingsActivity extends AppCompatActivity{
 int dp(float x){return(int)(x*getResources().getDisplayMetrics().density+.5f);} TextView t(String s,float z,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);return v;}
 protected void onCreate(Bundle b){super.onCreate(b);LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(dp(16),dp(12),dp(16),dp(12));r.setBackgroundColor(Color.rgb(5,7,6));TextView h=t("‹   ⚙ SETTINGS",22,Color.rgb(120,240,0));h.setOnClickListener(v->finish());r.addView(h,new LinearLayout.LayoutParams(-1,dp(55)));
 Switch n=new Switch(this);n.setText("Notifications\nTampilkan notifikasi VEXORA");n.setTextColor(Color.WHITE);r.addView(n,new LinearLayout.LayoutParams(-1,dp(75)));
 Switch a=new Switch(this);a.setText("Auto Start UI\nBuka dashboard saat aplikasi dijalankan");a.setTextColor(Color.WHITE);r.addView(a,new LinearLayout.LayoutParams(-1,dp(75)));
 r.addView(t("VEXORA v1.1\nDark neon gaming utility",12,Color.GRAY),new LinearLayout.LayoutParams(-1,dp(80)));setContentView(r);}
}