package com.vexora.app;
import android.graphics.Color;import android.os.Bundle;import android.view.*;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;
public class MacroActivity extends AppCompatActivity{
 int dp(float x){return(int)(x*getResources().getDisplayMetrics().density+.5f);} TextView t(String s,float z,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);return v;}
 protected void onCreate(Bundle b){super.onCreate(b);LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(dp(16),dp(12),dp(16),dp(12));r.setBackgroundColor(Color.rgb(5,7,6));
 TextView h=t("‹   🎯 MACRO",23,Color.rgb(120,240,0));h.setOnClickListener(v->finish());r.addView(h,new LinearLayout.LayoutParams(-1,dp(55)));
 r.addView(t("MACRO LAB",25,Color.WHITE),new LinearLayout.LayoutParams(-1,dp(45)));
 r.addView(t("Safe configuration preview: points, timing, presets and ON/OFF UI.",12,Color.GRAY),new LinearLayout.LayoutParams(-1,dp(55)));
 for(int i=1;i<=3;i++){LinearLayout c=new LinearLayout(this);c.setPadding(dp(14),dp(8),dp(14),dp(8));c.setGravity(Gravity.CENTER_VERTICAL);c.setBackgroundResource(R.drawable.bg_card);c.addView(t("POINT "+i,15,Color.WHITE),new LinearLayout.LayoutParams(0,dp(55),1));Button p=new Button(this);p.setText("EDIT");p.setTextColor(Color.BLACK);p.setBackgroundResource(R.drawable.bg_button);c.addView(p,new LinearLayout.LayoutParams(dp(90),dp(48)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(72));lp.setMargins(0,dp(8),0,0);r.addView(c,lp);}
 Switch s=new Switch(this);s.setText("MACRO ENABLED\nUI demo only — no automated input");s.setTextColor(Color.WHITE);s.setTextSize(14);r.addView(s,new LinearLayout.LayoutParams(-1,dp(75)));
 Button save=new Button(this);save.setText("SAVE PRESET");save.setTextColor(Color.BLACK);save.setBackgroundResource(R.drawable.bg_button);r.addView(save,new LinearLayout.LayoutParams(-1,dp(54)));save.setOnClickListener(v->Toast.makeText(this,"Preset tersimpan.",Toast.LENGTH_SHORT).show());setContentView(r);}
}